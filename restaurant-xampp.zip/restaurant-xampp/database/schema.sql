-- Import this file in phpMyAdmin (XAMPP) or via:
--   mysql -u root -p < schema.sql
CREATE DATABASE IF NOT EXISTS restaurant_db;
USE restaurant_db;

CREATE TABLE IF NOT EXISTS tables_master (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(20) NOT NULL,
  capacity INT NOT NULL,
  zone VARCHAR(20) NOT NULL DEFAULT 'main',
  status ENUM('available','reserved','occupied','cleaning') NOT NULL DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  table_id INT NOT NULL,
  guest_name VARCHAR(100) NOT NULL,
  party_size INT NOT NULL,
  phone VARCHAR(30),
  reserved_for DATETIME NOT NULL,
  status ENUM('upcoming','seated','completed','cancelled','no_show') NOT NULL DEFAULT 'upcoming',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (table_id) REFERENCES tables_master(id)
);

CREATE TABLE IF NOT EXISTS menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(30) NOT NULL,
  base_price DECIMAL(8,2) NOT NULL,
  prep_minutes INT NOT NULL DEFAULT 10,
  spice_profile VARCHAR(20) DEFAULT 'medium',
  is_86ed TINYINT(1) NOT NULL DEFAULT 0,
  popularity_score DECIMAL(8,2) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  table_id INT NOT NULL,
  server_name VARCHAR(100) NOT NULL DEFAULT 'Unassigned',
  status ENUM('placed','preparing','ready','served','billed','cancelled') NOT NULL DEFAULT 'placed',
  applied_price_multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.0,
  placed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (table_id) REFERENCES tables_master(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menu_item_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(8,2) NOT NULL,
  notes VARCHAR(255),
  course VARCHAR(30) NOT NULL DEFAULT 'main',
  status ENUM('queued','firing','plated','served') NOT NULL DEFAULT 'queued',
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);

CREATE TABLE IF NOT EXISTS invoices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  subtotal DECIMAL(8,2) NOT NULL,
  tax DECIMAL(8,2) NOT NULL,
  service_charge DECIMAL(8,2) NOT NULL,
  total DECIMAL(8,2) NOT NULL,
  payment_method VARCHAR(20),
  paid_at TIMESTAMP NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE TABLE IF NOT EXISTS floor_signals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  occupancy_pct DECIMAL(5,2) NOT NULL,
  kitchen_load_pct DECIMAL(5,2) NOT NULL,
  avg_wait_minutes DECIMAL(6,2) NOT NULL,
  price_multiplier DECIMAL(4,2) NOT NULL
);

-- Seed demo data
INSERT INTO tables_master (label, capacity, zone) VALUES
('T1',2,'main'),('T2',2,'main'),('T3',4,'main'),('T4',4,'main'),
('T5',6,'main'),('T6',4,'patio'),('T7',2,'patio'),('T8',8,'private');

INSERT INTO menu_items (name, category, base_price, prep_minutes, spice_profile) VALUES
('Tomato Basil Soup','starter',6.50,6,'mild'),
('Crispy Calamari','starter',9.00,8,'medium'),
('Garden Salad','starter',7.00,4,'mild'),
('Grilled Salmon','main',22.00,16,'mild'),
('Margherita Pizza','main',14.00,12,'mild'),
('Butter Chicken','main',16.50,18,'hot'),
('Mushroom Risotto','main',15.00,15,'mild'),
('Char-Grilled Ribeye','main',28.00,20,'medium'),
('Molten Chocolate Cake','dessert',8.00,10,'mild'),
('Tiramisu','dessert',7.50,5,'mild'),
('House Red Wine (glass)','beverage',9.00,2,'n/a'),
('Sparkling Water','beverage',3.00,1,'n/a'),
('Craft Lemonade','beverage',4.50,2,'n/a');
