// db.js — MySQL connection pool (XAMPP's MySQL server).
// Default XAMPP creds: host=localhost, user=root, password="" (empty).
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "restaurant_db",
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
