// engine.js — the intelligence layer, ported to async MySQL queries.
const pool = require("./db");

async function computeFloorSignals() {
  const [[tableCounts]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(status='occupied') AS occupied FROM tables_master`
  );
  const occupancy_pct = tableCounts.total ? Math.round((tableCounts.occupied / tableCounts.total) * 100) : 0;

  const [[kitchenCounts]] = await pool.query(
    `SELECT COUNT(*) AS active FROM orders WHERE status IN ('placed','preparing')`
  );
  const kitchen_load_pct = Math.min(100, Math.round((kitchenCounts.active / 8) * 100));

  const [[waitRow]] = await pool.query(
    `SELECT AVG(TIMESTAMPDIFF(MINUTE, placed_at, NOW())) AS avg_min
     FROM orders WHERE status IN ('placed','preparing')`
  );
  const avg_wait_minutes = waitRow.avg_min ? Math.round(waitRow.avg_min) : 0;

  const demandScore = occupancy_pct * 0.6 + kitchen_load_pct * 0.4;
  let price_multiplier;
  if (demandScore < 30) price_multiplier = 0.9;
  else if (demandScore < 55) price_multiplier = 1.0;
  else if (demandScore < 75) price_multiplier = 1.08;
  else if (demandScore < 90) price_multiplier = 1.15;
  else price_multiplier = 1.2;

  await pool.query(
    `INSERT INTO floor_signals (occupancy_pct, kitchen_load_pct, avg_wait_minutes, price_multiplier) VALUES (?,?,?,?)`,
    [occupancy_pct, kitchen_load_pct, avg_wait_minutes, price_multiplier]
  );

  return { occupancy_pct, kitchen_load_pct, avg_wait_minutes, price_multiplier };
}

async function suggestTable(partySize, preferredZone) {
  const [candidates] = await pool.query(
    `SELECT * FROM tables_master WHERE status='available' AND capacity >= ? ORDER BY capacity ASC`,
    [partySize]
  );
  if (candidates.length === 0) return null;
  const zoneMatch = preferredZone ? candidates.find((t) => t.zone === preferredZone) : null;
  const best = zoneMatch || candidates[0];
  const wasted = best.capacity - partySize;
  return {
    table: best,
    fit_score: Math.max(0, 100 - wasted * 15),
    reason: wasted === 0
      ? "Exact capacity match — zero wasted seats."
      : `Smallest available table that fits the party (${wasted} spare seat${wasted === 1 ? "" : "s"}).`,
  };
}

const COURSE_ORDER = ["starter", "main", "dessert", "beverage"];
const COURSE_GAP_MINUTES = { starter: 0, main: 4, dessert: 12, beverage: 0 };

function buildCoursePacingPlan(items) {
  const grouped = {};
  for (const item of items) {
    grouped[item.course] = grouped[item.course] || [];
    grouped[item.course].push(item);
  }
  let clock = 0;
  const plan = [];
  for (const course of COURSE_ORDER) {
    if (!grouped[course]) continue;
    clock += COURSE_GAP_MINUTES[course] || 0;
    const maxPrep = Math.max(...grouped[course].map((i) => i.prep_minutes));
    plan.push({ course, fire_at_minute: clock, items: grouped[course].map((i) => i.name), estimated_ready_minute: clock + maxPrep });
    clock += maxPrep;
  }
  return plan;
}

function suggestPairings(cartCategories) {
  const suggestions = [];
  const has = (c) => cartCategories.includes(c);
  if (has("main") && !has("beverage")) suggestions.push({ nudge: "No drink order yet", detail: "Suggest a house beverage pairing for the main course." });
  if (has("main") && !has("starter")) suggestions.push({ nudge: "Skip-the-starter table", detail: "Offer a quick small plate while mains are fired." });
  if (!has("dessert")) suggestions.push({ nudge: "No dessert yet", detail: "Prompt dessert menu near estimated main-course completion." });
  return suggestions;
}

module.exports = { computeFloorSignals, suggestTable, buildCoursePacingPlan, suggestPairings };
