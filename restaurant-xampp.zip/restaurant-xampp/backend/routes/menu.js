const express = require("express");
const pool = require("../db");
const { computeFloorSignals } = require("../engine");
const router = express.Router();

router.get("/", async (req, res) => {
  const [items] = await pool.query(`SELECT * FROM menu_items ORDER BY category, name`);
  const { price_multiplier } = await computeFloorSignals();
  const priced = items.map((i) => ({ ...i, base_price: Number(i.base_price), live_price: Math.round(i.base_price * price_multiplier * 100) / 100 }));
  res.json({ items: priced, price_multiplier });
});

router.post("/", async (req, res) => {
  const { name, category, base_price, prep_minutes, spice_profile } = req.body;
  if (!name || !category || !base_price) return res.status(400).json({ error: "missing fields" });
  const [r] = await pool.query(
    `INSERT INTO menu_items (name, category, base_price, prep_minutes, spice_profile) VALUES (?,?,?,?,?)`,
    [name, category, base_price, prep_minutes || 10, spice_profile || "medium"]
  );
  const [[row]] = await pool.query(`SELECT * FROM menu_items WHERE id=?`, [r.insertId]);
  res.status(201).json(row);
});

router.patch("/:id/86", async (req, res) => {
  const { is_86ed } = req.body;
  await pool.query(`UPDATE menu_items SET is_86ed=? WHERE id=?`, [is_86ed ? 1 : 0, req.params.id]);
  const [[row]] = await pool.query(`SELECT * FROM menu_items WHERE id=?`, [req.params.id]);
  res.json(row);
});

module.exports = router;
