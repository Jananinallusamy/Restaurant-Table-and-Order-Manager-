const express = require("express");
const pool = require("../db");
const router = express.Router();
const TAX_RATE = 0.05;
const SERVICE_CHARGE_RATE = 0.1;

router.post("/:orderId/invoice", async (req, res) => {
  const orderId = req.params.orderId;
  const [[existing]] = await pool.query(`SELECT * FROM invoices WHERE order_id=?`, [orderId]);
  if (existing) return res.json(existing);

  const [items] = await pool.query(`SELECT quantity, unit_price FROM order_items WHERE order_id=?`, [orderId]);
  if (items.length === 0) return res.status(404).json({ error: "order has no items" });

  const subtotal = items.reduce((s, i) => s + i.quantity * Number(i.unit_price), 0);
  const tax = Math.round(subtotal * TAX_RATE * 100) / 100;
  const service_charge = Math.round(subtotal * SERVICE_CHARGE_RATE * 100) / 100;
  const total = Math.round((subtotal + tax + service_charge) * 100) / 100;

  const [r] = await pool.query(
    `INSERT INTO invoices (order_id, subtotal, tax, service_charge, total) VALUES (?,?,?,?,?)`,
    [orderId, Math.round(subtotal * 100) / 100, tax, service_charge, total]
  );
  const [[row]] = await pool.query(`SELECT * FROM invoices WHERE id=?`, [r.insertId]);
  res.status(201).json(row);
});

router.post("/:orderId/pay", async (req, res) => {
  const { payment_method } = req.body;
  const orderId = req.params.orderId;
  const [[invoice]] = await pool.query(`SELECT * FROM invoices WHERE order_id=?`, [orderId]);
  if (!invoice) return res.status(404).json({ error: "generate an invoice first" });

  await pool.query(`UPDATE invoices SET payment_method=?, paid_at=NOW() WHERE id=?`, [payment_method || "card", invoice.id]);
  await pool.query(`UPDATE orders SET status='billed' WHERE id=?`, [orderId]);
  const [[order]] = await pool.query(`SELECT table_id FROM orders WHERE id=?`, [orderId]);
  await pool.query(`UPDATE tables_master SET status='cleaning' WHERE id=?`, [order.table_id]);

  const [[row]] = await pool.query(`SELECT * FROM invoices WHERE id=?`, [invoice.id]);
  res.json(row);
});

module.exports = router;
