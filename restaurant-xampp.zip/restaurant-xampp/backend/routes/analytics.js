const express = require("express");
const pool = require("../db");
const { computeFloorSignals } = require("../engine");
const router = express.Router();

router.get("/floor", async (req, res) => res.json(await computeFloorSignals()));

router.get("/floor/history", async (req, res) => {
  const [rows] = await pool.query(`SELECT * FROM floor_signals ORDER BY recorded_at DESC LIMIT 50`);
  res.json(rows.reverse());
});

router.get("/revenue", async (req, res) => {
  const [[today]] = await pool.query(
    `SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS invoice_count FROM invoices WHERE paid_at IS NOT NULL AND DATE(paid_at)=CURDATE()`
  );
  const [[allTime]] = await pool.query(`SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS invoice_count FROM invoices WHERE paid_at IS NOT NULL`);
  res.json({ today: { total: Number(today.total), invoice_count: today.invoice_count }, all_time: { total: Number(allTime.total), invoice_count: allTime.invoice_count } });
});

router.get("/popular", async (req, res) => {
  const [rows] = await pool.query(`SELECT name, category, popularity_score FROM menu_items ORDER BY popularity_score DESC LIMIT 8`);
  res.json(rows.map(r => ({...r, popularity_score: Number(r.popularity_score)})));
});

module.exports = router;
