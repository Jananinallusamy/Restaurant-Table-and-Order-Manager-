const express = require("express");
const pool = require("../db");
const router = express.Router();

router.get("/tickets", async (req, res) => {
  const [orders] = await pool.query(
    `SELECT o.id, o.table_id, o.server_name, o.status, o.placed_at, t.label AS table_label
     FROM orders o JOIN tables_master t ON t.id=o.table_id
     WHERE o.status IN ('placed','preparing','ready') ORDER BY o.placed_at ASC`
  );
  const tickets = [];
  for (const o of orders) {
    const [items] = await pool.query(
      `SELECT oi.id, oi.quantity, oi.notes, oi.course, oi.status, mi.name, mi.prep_minutes
       FROM order_items oi JOIN menu_items mi ON mi.id=oi.menu_item_id WHERE oi.order_id=?`,
      [o.id]
    );
    const maxPrep = items.length ? Math.max(...items.map((i) => i.prep_minutes)) : 0;
    tickets.push({ ...o, items, estimated_minutes: maxPrep });
  }
  res.json(tickets);
});

router.patch("/items/:itemId/status", async (req, res) => {
  const { status } = req.body;
  const valid = ["queued", "firing", "plated", "served"];
  if (!valid.includes(status)) return res.status(400).json({ error: "invalid status" });
  await pool.query(`UPDATE order_items SET status=? WHERE id=?`, [status, req.params.itemId]);

  const [[item]] = await pool.query(`SELECT order_id FROM order_items WHERE id=?`, [req.params.itemId]);
  if (item) {
    const [[remaining]] = await pool.query(
      `SELECT COUNT(*) AS c FROM order_items WHERE order_id=? AND status NOT IN ('plated','served')`,
      [item.order_id]
    );
    if (remaining.c === 0) {
      await pool.query(`UPDATE orders SET status='ready' WHERE id=?`, [item.order_id]);
    } else {
      await pool.query(`UPDATE orders SET status='preparing' WHERE id=? AND status='placed'`, [item.order_id]);
    }
  }
  const [[row]] = await pool.query(`SELECT * FROM order_items WHERE id=?`, [req.params.itemId]);
  res.json(row);
});

module.exports = router;
