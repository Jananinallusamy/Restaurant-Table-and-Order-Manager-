const express = require("express");
const pool = require("../db");
const { computeFloorSignals, buildCoursePacingPlan, suggestPairings } = require("../engine");
const router = express.Router();

async function hydrateOrder(orderId) {
  const [[order]] = await pool.query(`SELECT * FROM orders WHERE id=?`, [orderId]);
  if (!order) return null;
  const [items] = await pool.query(
    `SELECT oi.*, mi.name, mi.category FROM order_items oi JOIN menu_items mi ON mi.id=oi.menu_item_id WHERE oi.order_id=?`,
    [orderId]
  );
  const [[table]] = await pool.query(`SELECT label FROM tables_master WHERE id=?`, [order.table_id]);
  return { ...order, applied_price_multiplier: Number(order.applied_price_multiplier), table_label: table?.label, items: items.map(i => ({...i, unit_price: Number(i.unit_price)})) };
}

router.get("/", async (req, res) => {
  const { status } = req.query;
  const [rows] = status
    ? await pool.query(`SELECT id FROM orders WHERE status=? ORDER BY placed_at`, [status])
    : await pool.query(`SELECT id FROM orders ORDER BY placed_at`);
  res.json(await Promise.all(rows.map((r) => hydrateOrder(r.id))));
});

router.get("/:id", async (req, res) => {
  const order = await hydrateOrder(req.params.id);
  if (!order) return res.status(404).json({ error: "not found" });
  res.json(order);
});

router.post("/", async (req, res) => {
  const { table_id, server_name, items } = req.body;
  if (!table_id || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: "table_id and items required" });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { price_multiplier } = await computeFloorSignals();
    const [orderResult] = await conn.query(
      `INSERT INTO orders (table_id, server_name, applied_price_multiplier) VALUES (?,?,?)`,
      [table_id, server_name || "Unassigned", price_multiplier]
    );
    const orderId = orderResult.insertId;

    for (const item of items) {
      const [[menuItem]] = await conn.query(`SELECT * FROM menu_items WHERE id=?`, [item.menu_item_id]);
      if (!menuItem) throw new Error(`menu item ${item.menu_item_id} not found`);
      if (menuItem.is_86ed) throw new Error(`${menuItem.name} is currently 86'd`);
      const unitPrice = Math.round(menuItem.base_price * price_multiplier * 100) / 100;
      await conn.query(
        `INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price, notes, course) VALUES (?,?,?,?,?,?)`,
        [orderId, menuItem.id, item.quantity || 1, unitPrice, item.notes || null, item.course || menuItem.category]
      );
      await conn.query(`UPDATE menu_items SET popularity_score = popularity_score + ? WHERE id=?`, [item.quantity || 1, menuItem.id]);
    }
    await conn.query(`UPDATE tables_master SET status='occupied' WHERE id=?`, [table_id]);
    await conn.commit();
    res.status(201).json(await hydrateOrder(orderId));
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ error: err.message });
  } finally {
    conn.release();
  }
});

router.patch("/:id/status", async (req, res) => {
  const { status } = req.body;
  const valid = ["placed", "preparing", "ready", "served", "billed", "cancelled"];
  if (!valid.includes(status)) return res.status(400).json({ error: "invalid status" });
  await pool.query(`UPDATE orders SET status=? WHERE id=?`, [status, req.params.id]);
  res.json(await hydrateOrder(req.params.id));
});

router.get("/:id/pacing-plan", async (req, res) => {
  const order = await hydrateOrder(req.params.id);
  if (!order) return res.status(404).json({ error: "not found" });
  const items = [];
  for (const i of order.items) {
    const [[m]] = await pool.query(`SELECT prep_minutes FROM menu_items WHERE id=?`, [i.menu_item_id]);
    items.push({ name: i.name, course: i.course, prep_minutes: m.prep_minutes });
  }
  res.json({ order_id: order.id, plan: buildCoursePacingPlan(items) });
});

router.get("/:id/upsell", async (req, res) => {
  const order = await hydrateOrder(req.params.id);
  if (!order) return res.status(404).json({ error: "not found" });
  const categories = [...new Set(order.items.map((i) => i.category))];
  res.json({ order_id: order.id, suggestions: suggestPairings(categories) });
});

module.exports = router;
