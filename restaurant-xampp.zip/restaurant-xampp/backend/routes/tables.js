const express = require("express");
const pool = require("../db");
const { suggestTable } = require("../engine");
const router = express.Router();

router.get("/", async (req, res) => {
  const [rows] = await pool.query(`SELECT * FROM tables_master ORDER BY label`);
  res.json(rows);
});

router.post("/", async (req, res) => {
  const { label, capacity, zone } = req.body;
  if (!label || !capacity) return res.status(400).json({ error: "label and capacity required" });
  const [r] = await pool.query(`INSERT INTO tables_master (label, capacity, zone) VALUES (?,?,?)`, [label, capacity, zone || "main"]);
  const [[row]] = await pool.query(`SELECT * FROM tables_master WHERE id=?`, [r.insertId]);
  res.status(201).json(row);
});

router.patch("/:id/status", async (req, res) => {
  const { status } = req.body;
  const valid = ["available", "reserved", "occupied", "cleaning"];
  if (!valid.includes(status)) return res.status(400).json({ error: "invalid status" });
  await pool.query(`UPDATE tables_master SET status=? WHERE id=?`, [status, req.params.id]);
  const [[row]] = await pool.query(`SELECT * FROM tables_master WHERE id=?`, [req.params.id]);
  res.json(row);
});

router.get("/suggest", async (req, res) => {
  const partySize = parseInt(req.query.party_size, 10);
  if (!partySize) return res.status(400).json({ error: "party_size is required" });
  const suggestion = await suggestTable(partySize, req.query.zone);
  if (!suggestion) return res.status(404).json({ error: "No available table fits this party right now" });
  res.json(suggestion);
});

router.get("/reservations/all", async (req, res) => {
  const [rows] = await pool.query(
    `SELECT r.*, t.label AS table_label FROM reservations r JOIN tables_master t ON t.id=r.table_id ORDER BY r.reserved_for ASC`
  );
  res.json(rows);
});

router.post("/reservations", async (req, res) => {
  const { table_id, guest_name, party_size, phone, reserved_for } = req.body;
  if (!table_id || !guest_name || !party_size || !reserved_for) return res.status(400).json({ error: "missing fields" });
  const [r] = await pool.query(
    `INSERT INTO reservations (table_id, guest_name, party_size, phone, reserved_for) VALUES (?,?,?,?,?)`,
    [table_id, guest_name, party_size, phone || null, reserved_for]
  );
  await pool.query(`UPDATE tables_master SET status='reserved' WHERE id=?`, [table_id]);
  const [[row]] = await pool.query(`SELECT * FROM reservations WHERE id=?`, [r.insertId]);
  res.status(201).json(row);
});

router.patch("/reservations/:id/status", async (req, res) => {
  const { status } = req.body;
  const valid = ["upcoming", "seated", "completed", "cancelled", "no_show"];
  if (!valid.includes(status)) return res.status(400).json({ error: "invalid status" });
  const [[reservation]] = await pool.query(`SELECT * FROM reservations WHERE id=?`, [req.params.id]);
  if (!reservation) return res.status(404).json({ error: "not found" });
  await pool.query(`UPDATE reservations SET status=? WHERE id=?`, [status, req.params.id]);
  const tableStatus = status === "seated" ? "occupied" : status === "upcoming" ? "reserved" : "available";
  await pool.query(`UPDATE tables_master SET status=? WHERE id=?`, [tableStatus, reservation.table_id]);
  const [[row]] = await pool.query(`SELECT * FROM reservations WHERE id=?`, [req.params.id]);
  res.json(row);
});

module.exports = router;
