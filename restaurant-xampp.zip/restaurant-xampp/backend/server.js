const express = require("express");
const cors = require("cors");

const tablesRouter = require("./routes/tables");
const menuRouter = require("./routes/menu");
const ordersRouter = require("./routes/orders");
const kitchenRouter = require("./routes/kitchen");
const billingRouter = require("./routes/billing");
const analyticsRouter = require("./routes/analytics");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get("/api/health", (req, res) => res.json({ ok: true, service: "restaurant-backend-js", db: "mysql/xampp" }));

app.use("/api/tables", tablesRouter);
app.use("/api/menu", menuRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/kitchen", kitchenRouter);
app.use("/api/billing", billingRouter);
app.use("/api/analytics", analyticsRouter);

app.use((req, res) => res.status(404).json({ error: "Not found" }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

app.listen(PORT, () => console.log(`Backend (JS/Express + MySQL) running on http://localhost:${PORT}`));
