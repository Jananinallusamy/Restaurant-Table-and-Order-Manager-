# The Rail — Restaurant Table & Order Management System
Stack: **Frontend = Python (Flask)** · **Backend = JavaScript (Node/Express)** · **Database = MySQL via XAMPP**

## Folder layout
```
restaurant-xampp/
├── database/
│   └── schema.sql        Import in phpMyAdmin (or mysql CLI) — creates DB + tables + demo seed data
├── backend/               Node.js + Express REST API, talks to MySQL
│   ├── db.js               mysql2 connection pool (XAMPP defaults: root / no password)
│   ├── engine.js           The 4 intelligence engines (pricing, table allocation, pacing, upsell)
│   ├── routes/             REST endpoints (tables, menu, orders, kitchen, billing, analytics)
│   └── server.js
└── frontend/               Flask app — server-rendered pages, fetch() calls to the backend API
    ├── app.py
    ├── templates/           floor.html, menu.html, pos.html, kitchen.html, billing.html, analytics.html
    └── static/              style.css, api.js
```

## Setup (in order)

### 1. Start XAMPP, create the database
- Open XAMPP Control Panel → start **Apache** and **MySQL**.
- Open phpMyAdmin (`http://localhost/phpmyadmin`) → Import → choose `database/schema.sql` → Go.
  (Or from a terminal: `mysql -u root -p < database/schema.sql`.)

This creates `restaurant_db` with all tables and demo seed data (8 tables, 13 menu items).

### 2. Backend (Node/Express)
```bash
cd backend
npm install
npm start           # http://localhost:4000
```
If your XAMPP MySQL uses a non-default user/password/port, set env vars before `npm start`:
```bash
set DB_USER=root
set DB_PASSWORD=yourpassword
set DB_PORT=3306
```
(on macOS/Linux use `export` instead of `set`)

### 3. Frontend (Python/Flask)
```bash
cd frontend
python -m venv venv
venv\Scripts\activate        # or: source venv/bin/activate
pip install -r requirements.txt
python app.py                # http://localhost:5000
```

Open `http://localhost:5000` in your browser. The Flask pages call the Express
API at `http://localhost:4000/api` client-side (see `frontend/static/api.js`).

## The four innovation engines (`backend/engine.js`)
1. **Adaptive Demand Pricing** — live 0.90×–1.20× multiplier from occupancy + kitchen load.
2. **Smart Table Allocation** — suggests smallest available table that fits the party.
3. **Course Pacing** — staggers course fire-times (starter → main → dessert → beverage).
4. **Pairing / Upsell Nudges** — rule-based suggestions from live cart contents.

## Pages
Floor & Tables · Menu · Order/POS · Kitchen Rail (ticket KDS) · Billing · Analytics

## Notes
- CORS is enabled on the backend so the Flask app (port 5000) can call it (port 4000).
- No authentication included — add one before real deployment.
- To reset demo data, drop and re-import `schema.sql`.
