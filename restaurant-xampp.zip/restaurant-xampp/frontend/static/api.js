// api.js — talks to the Node/Express backend (set in <body data-api-base>).
const API_BASE = document.body.dataset.apiBase;

async function apiRequest(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${path}`);
  return data;
}

const api = {
  getTables: () => apiRequest("/tables"),
  addTable: (body) => apiRequest("/tables", { method: "POST", body: JSON.stringify(body) }),
  setTableStatus: (id, status) => apiRequest(`/tables/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }),
  suggestTable: (partySize, zone) => apiRequest(`/tables/suggest?party_size=${partySize}${zone ? `&zone=${zone}` : ""}`),
  getReservations: () => apiRequest("/tables/reservations/all"),
  addReservation: (body) => apiRequest("/tables/reservations", { method: "POST", body: JSON.stringify(body) }),
  setReservationStatus: (id, status) => apiRequest(`/tables/reservations/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }),

  getMenu: () => apiRequest("/menu"),
  addMenuItem: (body) => apiRequest("/menu", { method: "POST", body: JSON.stringify(body) }),
  toggle86: (id, is_86ed) => apiRequest(`/menu/${id}/86`, { method: "PATCH", body: JSON.stringify({ is_86ed }) }),

  getOrders: (status) => apiRequest(`/orders${status ? `?status=${status}` : ""}`),
  getOrder: (id) => apiRequest(`/orders/${id}`),
  placeOrder: (body) => apiRequest("/orders", { method: "POST", body: JSON.stringify(body) }),
  setOrderStatus: (id, status) => apiRequest(`/orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }),
  getPacingPlan: (id) => apiRequest(`/orders/${id}/pacing-plan`),
  getUpsell: (id) => apiRequest(`/orders/${id}/upsell`),

  getTickets: () => apiRequest("/kitchen/tickets"),
  setItemStatus: (itemId, status) => apiRequest(`/kitchen/items/${itemId}/status`, { method: "PATCH", body: JSON.stringify({ status }) }),

  generateInvoice: (orderId) => apiRequest(`/billing/${orderId}/invoice`, { method: "POST" }),
  payInvoice: (orderId, payment_method) => apiRequest(`/billing/${orderId}/pay`, { method: "POST", body: JSON.stringify({ payment_method }) }),

  getFloorSignals: () => apiRequest("/analytics/floor"),
  getRevenue: () => apiRequest("/analytics/revenue"),
  getPopular: () => apiRequest("/analytics/popular"),
};

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function pillHtml(status) {
  return `<span class="pill pill-${status}">${String(status).replace("_", " ")}</span>`;
}
