"""
Flask frontend for The Rail restaurant system.
Renders server-side templates; all live data is fetched client-side (JS)
from the Node/Express backend API (see backend/), which talks to MySQL/XAMPP.
"""
from flask import Flask, render_template

app = Flask(__name__)

# Base URL of the Node/Express backend. Change if hosted elsewhere.
API_BASE = "http://localhost:4000/api"

NAV = [
    {"href": "/", "num": "01", "label": "Floor & Tables"},
    {"href": "/menu", "num": "02", "label": "Menu"},
    {"href": "/pos", "num": "03", "label": "Order / POS"},
    {"href": "/kitchen", "num": "04", "label": "Kitchen Rail"},
    {"href": "/billing", "num": "05", "label": "Billing"},
    {"href": "/analytics", "num": "06", "label": "Analytics"},
]


def render(template_name, active):
    return render_template(template_name, nav=NAV, active=active, api_base=API_BASE)


@app.route("/")
def floor():
    return render("floor.html", "/")


@app.route("/menu")
def menu():
    return render("menu.html", "/menu")


@app.route("/pos")
def pos():
    return render("pos.html", "/pos")


@app.route("/kitchen")
def kitchen():
    return render("kitchen.html", "/kitchen")


@app.route("/billing")
def billing():
    return render("billing.html", "/billing")


@app.route("/analytics")
def analytics():
    return render("analytics.html", "/analytics")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
